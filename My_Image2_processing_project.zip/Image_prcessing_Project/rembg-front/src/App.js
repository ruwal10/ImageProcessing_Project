import './App.css';
import axios from 'axios';
import { useState } from 'react';
import Avatar from './assets/avatar.jpg';
import Button from '@mui/material/Button';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { styled } from '@mui/material/styles';
import { saveAs } from "file-saver";
import { createTheme, ThemeProvider } from '@mui/material/styles';
import CircularProgress from '@mui/material/CircularProgress';

const theme = createTheme({
  palette: {
    ochre: {
      main: '#E3D026',
      light: '#E9DB5D',
      dark: '#A29415',
      contrastText: '#242105',
    },
    ochreDark: {
      main: '#E9DB5D',
      light: '#E9DB5D',
      dark: '#A29415',
      contrastText: '#242105',
    }
  },
});
const VisuallyHiddenInput = styled('input')({
  clip: 'rect(0 0 0 0)',
  clipPath: 'inset(50%)',
  height: 1,
  overflow: 'hidden',
  position: 'absolute',
  bottom: 0,
  left: 0,
  whiteSpace: 'nowrap',
  width: 1,
});

function App() {
  const [inputImgSrc, setInputImgSrc] = useState('');
  const [inputUrl, setInputUrl] = useState(null);
  const [imgSrc, setSrc] = useState('');
  const [loading, setLoading] = useState(false);

  const sendFile = (e) => {
    setInputImgSrc(URL.createObjectURL(e.target.files[0]));
    setInputUrl(e.target.files[0]);
  }

  const removebackground = async () => {
    setLoading(true);
    let formData = new FormData();
    formData.append("file", inputUrl);
    const res = await axios({
      url: "http://127.0.0.1:8000/upload/filename",
      method: "POST",
      data: formData
    });
    setSrc(res.data.file_url);
    setLoading(false);
  }

  const downloadImage = () => {
    saveAs(imgSrc, "output");
  }

  return (
    <div className="App">
      <ThemeProvider theme={theme}>
        <h2>Remove Image Background</h2>
        <header className="App-header">
          <img className='img-design' height={400} width={400} src={inputImgSrc ? inputImgSrc : Avatar} />
          <div className='buttons'>
            <Button color="ochre" component="label" variant="outlined" startIcon={<CloudUploadIcon />}>
              Upload file
              <VisuallyHiddenInput onChange={(e) => sendFile(e)} type="file" />
            </Button>
            <Button color="ochreDark" disabled={!inputImgSrc} variant="contained" onClick={removebackground}>Remove Background</Button>
            <Button color="ochre" disabled={!imgSrc} variant="contained" onClick={downloadImage}>Download</Button>
          </div>
          <div className='img-design'>
            {
              loading ?
                <CircularProgress className='loader' />
                :
                <img height={400} width={400} src={imgSrc ? imgSrc : Avatar} />
            }
          </div>
        </header>
      </ThemeProvider>
    </div>
  );
}

export default App;
