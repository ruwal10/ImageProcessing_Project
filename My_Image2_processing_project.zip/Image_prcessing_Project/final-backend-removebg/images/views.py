from rest_framework.views import APIView
from rest_framework.parsers import MultiPartParser
from rest_framework.response import Response
from django.core.files.storage import default_storage
from rembg import remove
import cv2

# Create your views here.

class FileUploadView(APIView):
    parser_classes = [MultiPartParser]

    def post(self, request, filename, format=None):
        file = request.FILES['file'];

        file_name = default_storage.save(file.name, file)

        #  Reading file from storage
        file = default_storage.open(file_name)
        input_path = default_storage.url(file_name)
        input_path = input_path[1:]
        output_path = 'media/output'+file_name

        input = cv2.imread(input_path)
        output = remove(input)
        cv2.imwrite(output_path, output)

        return Response({'file_url': 'http://127.0.0.1:8000/'+output_path});
