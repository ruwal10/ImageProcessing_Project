pip install rembg
https://github.com/danielgatis/rembg

pip install djangorestframework

Run:
py manage.py runserver